import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dbPath = await getDatabasesPath();
    _db = await openDatabase(
      join(dbPath, 'mera_products_v2.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE products(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            sku TEXT,
            category TEXT,
            color TEXT,
            size TEXT,
            stock INTEGER NOT NULL DEFAULT 0,
            cost_price INTEGER NOT NULL DEFAULT 0,
            sale_price INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
          )
        ''');
      },
    );
    return _db!;
  }

  Future<int> addProduct(Map<String, Object?> product) async =>
      (await database).insert('products', product);

  Future<List<Map<String, Object?>>> getProducts() async =>
      (await database).query('products', orderBy: 'id DESC');

  Future<int> deleteProduct(int id) async =>
      (await database).delete('products', where: 'id = ?', whereArgs: [id]);

  Future<int> productCount() async {
    final rows = await (await database).rawQuery('SELECT COUNT(*) AS c FROM products');
    return Sqflite.firstIntValue(rows) ?? 0;
  }

  Future<int> totalStock() async {
    final rows = await (await database).rawQuery('SELECT COALESCE(SUM(stock),0) AS s FROM products');
    return Sqflite.firstIntValue(rows) ?? 0;
  }
}
