import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dbPath = await getDatabasesPath();
    _db = await openDatabase(
      p.join(dbPath, 'mera_manager.db'),
      version: 1,
      onCreate: (db, version) async {
        final batch = db.batch();
        final statements = [
          '''CREATE TABLE products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sku TEXT UNIQUE,
            name TEXT NOT NULL,
            description TEXT,
            purchase_price INTEGER NOT NULL DEFAULT 0,
            sale_price INTEGER NOT NULL DEFAULT 0,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
          )''',
          '''CREATE TABLE variants (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            color TEXT,
            size TEXT,
            barcode TEXT,
            stock_qty INTEGER NOT NULL DEFAULT 0,
            min_stock INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
          )''',
          '''CREATE TABLE product_images (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            file_path TEXT NOT NULL,
            is_primary INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
          )''',
          '''CREATE TABLE stock_movements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            variant_id INTEGER NOT NULL,
            movement_type TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            unit_cost INTEGER NOT NULL DEFAULT 0,
            reference_type TEXT,
            reference_id INTEGER,
            note TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(variant_id) REFERENCES variants(id)
          )''',
          '''CREATE TABLE customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            instagram_id TEXT,
            telegram_id TEXT,
            address TEXT,
            note TEXT,
            created_at TEXT NOT NULL
          )''',
          '''CREATE TABLE suppliers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            address TEXT,
            note TEXT,
            created_at TEXT NOT NULL
          )''',
          '''CREATE TABLE orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_code TEXT UNIQUE,
            customer_id INTEGER,
            channel TEXT NOT NULL DEFAULT 'in_person',
            status TEXT NOT NULL DEFAULT 'pending',
            subtotal INTEGER NOT NULL DEFAULT 0,
            discount INTEGER NOT NULL DEFAULT 0,
            shipping_cost INTEGER NOT NULL DEFAULT 0,
            total INTEGER NOT NULL DEFAULT 0,
            note TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(customer_id) REFERENCES customers(id)
          )''',
          '''CREATE TABLE order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            variant_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            unit_price INTEGER NOT NULL,
            unit_cost_snapshot INTEGER NOT NULL DEFAULT 0,
            line_total INTEGER NOT NULL,
            FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY(variant_id) REFERENCES variants(id)
          )''',
          '''CREATE TABLE returns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER,
            reason TEXT,
            refund_amount INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'received',
            created_at TEXT NOT NULL,
            FOREIGN KEY(order_id) REFERENCES orders(id)
          )''',
          '''CREATE TABLE return_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            return_id INTEGER NOT NULL,
            variant_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            restock INTEGER NOT NULL DEFAULT 1,
            FOREIGN KEY(return_id) REFERENCES returns(id) ON DELETE CASCADE,
            FOREIGN KEY(variant_id) REFERENCES variants(id)
          )''',
          '''CREATE TABLE expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT,
            amount INTEGER NOT NULL,
            note TEXT,
            created_at TEXT NOT NULL
          )''',
          '''CREATE TABLE cash_accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            opening_balance INTEGER NOT NULL DEFAULT 0,
            is_active INTEGER NOT NULL DEFAULT 1
          )''',
          '''CREATE TABLE cash_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account_id INTEGER NOT NULL,
            direction TEXT NOT NULL,
            amount INTEGER NOT NULL,
            related_type TEXT,
            related_id INTEGER,
            note TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(account_id) REFERENCES cash_accounts(id)
          )''',
          '''CREATE TABLE account_parties (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            party_type TEXT NOT NULL,
            party_id INTEGER NOT NULL,
            balance INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL
          )''',
          '''CREATE TABLE purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            supplier_id INTEGER,
            total INTEGER NOT NULL DEFAULT 0,
            paid INTEGER NOT NULL DEFAULT 0,
            note TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(supplier_id) REFERENCES suppliers(id)
          )''',
          '''CREATE TABLE purchase_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            purchase_id INTEGER NOT NULL,
            variant_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            unit_cost INTEGER NOT NULL,
            FOREIGN KEY(purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
            FOREIGN KEY(variant_id) REFERENCES variants(id)
          )''',
          '''CREATE TABLE audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id INTEGER,
            details TEXT,
            created_at TEXT NOT NULL
          )''',
          '''CREATE TABLE app_settings (
            key TEXT PRIMARY KEY,
            value TEXT
          )'''
        ];
        for (final sql in statements) {
          batch.execute(sql);
        }
        batch.execute("INSERT INTO cash_accounts(name, opening_balance) VALUES('صندوق اصلی', 0)");
        await batch.commit(noResult: true);
      },
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
    );
    return _db!;
  }

  Future<int> addProduct({
    required String name,
    required int purchasePrice,
    required int salePrice,
    required int initialStock,
    String? color,
    String? size,
    String? imagePath,
  }) async {
    final db = await database;
    return db.transaction((txn) async {
      final productId = await txn.insert('products', {
        'name': name,
        'purchase_price': purchasePrice,
        'sale_price': salePrice,
        'created_at': DateTime.now().toIso8601String(),
      });
      final variantId = await txn.insert('variants', {
        'product_id': productId,
        'color': color,
        'size': size,
        'stock_qty': initialStock,
      });
      if (imagePath != null) {
        await txn.insert('product_images', {
          'product_id': productId,
          'file_path': imagePath,
          'is_primary': 1,
        });
      }
      if (initialStock > 0) {
        await txn.insert('stock_movements', {
          'variant_id': variantId,
          'movement_type': 'opening',
          'quantity': initialStock,
          'unit_cost': purchasePrice,
          'note': 'موجودی اولیه',
          'created_at': DateTime.now().toIso8601String(),
        });
      }
      return productId;
    });
  }

  Future<List<Map<String, Object?>>> getProducts() async {
    final db = await database;
    return db.rawQuery('''
      SELECT p.*, 
        COALESCE(SUM(v.stock_qty), 0) AS total_stock,
        (SELECT file_path FROM product_images i WHERE i.product_id=p.id AND i.is_primary=1 LIMIT 1) AS image_path
      FROM products p
      LEFT JOIN variants v ON v.product_id=p.id
      WHERE p.is_active=1
      GROUP BY p.id
      ORDER BY p.id DESC
    ''');
  }

  Future<void> deleteProduct(int id) async {
    final db = await database;
    await db.update('products', {'is_active': 0}, where: 'id=?', whereArgs: [id]);
  }

  Future<int> productCount() async {
    final db = await database;
    final rows = await db.rawQuery('SELECT COUNT(*) AS c FROM products WHERE is_active=1');
    return Sqflite.firstIntValue(rows) ?? 0;
  }

  Future<int> totalStock() async {
    final db = await database;
    final rows = await db.rawQuery('SELECT COALESCE(SUM(stock_qty),0) AS c FROM variants');
    return Sqflite.firstIntValue(rows) ?? 0;
  }
}
