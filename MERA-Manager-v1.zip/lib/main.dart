import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'data/app_database.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDatabase.instance.database;
  runApp(const MeraApp());
}

class MeraApp extends StatelessWidget {
  const MeraApp({super.key});

  @override
  Widget build(BuildContext context) {
    const pink = Color(0xFFE9A8B8);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MERA',
      locale: const Locale('fa'),
      supportedLocales: const [Locale('fa'), Locale('en')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: pink),
        scaffoldBackgroundColor: const Color(0xFFF8F7F7),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Color(0xFF333333),
          centerTitle: true,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int count = 0;
  int stock = 0;
  List<Map<String, Object?>> products = [];

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    final rows = await AppDatabase.instance.getProducts();
    final c = await AppDatabase.instance.productCount();
    final s = await AppDatabase.instance.totalStock();
    if (!mounted) return;
    setState(() { products = rows; count = c; stock = s; });
  }

  Future<void> addProduct() async {
    final result = await Navigator.push<bool>(
      context, MaterialPageRoute(builder: (_) => const ProductFormPage()));
    if (result == true) refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MERA', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 2)),
        actions: [IconButton(onPressed: refresh, icon: const Icon(Icons.refresh))],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: addProduct,
        icon: const Icon(Icons.add),
        label: const Text('ثبت محصول'),
      ),
      body: RefreshIndicator(
        onRefresh: refresh,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xFFF5DDE4),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('مدیریت بوتیک', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                SizedBox(height: 5),
                Text('مدیریت کالاها و موجودی فروشگاه MERA'),
              ]),
            ),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: _StatCard(title: 'تعداد محصولات', value: '$count', icon: Icons.checkroom)),
              const SizedBox(width: 10),
              Expanded(child: _StatCard(title: 'موجودی کل', value: '$stock', icon: Icons.inventory_2)),
            ]),
            const SizedBox(height: 22),
            const Text('محصولات ثبت‌شده', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            if (products.isEmpty)
              const Padding(
                padding: EdgeInsets.all(30),
                child: Center(child: Text('هنوز محصولی ثبت نشده است.')),
              ),
            ...products.map((p) => Card(
              color: Colors.white,
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.checkroom)),
                title: Text('${p['name']}'),
                subtitle: Text('کد: ${p['sku'] ?? '—'}  |  قیمت فروش: ${_money(p['sale_price'])} تومان\nموجودی: ${p['stock']} عدد'),
                isThreeLine: true,
                trailing: IconButton(
                  tooltip: 'حذف محصول',
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    final yes = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('حذف محصول'),
                        content: const Text('این محصول حذف شود؟'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
                          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
                        ],
                      ),
                    );
                    if (yes == true) {
                      await AppDatabase.instance.deleteProduct(p['id'] as int);
                      refresh();
                    }
                  },
                ),
              ),
            )),
            const SizedBox(height: 90),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title, value;
  final IconData icon;
  const _StatCard({required this.title, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white,
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        Icon(icon, color: const Color(0xFFD58DA0)),
        const SizedBox(height: 8),
        Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        Text(title, style: const TextStyle(fontSize: 12)),
      ]),
    ),
  );
}

String _money(Object? value) {
  final n = (value as num?)?.toStringAsFixed(0) ?? '0';
  return n.replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
}

class ProductFormPage extends StatefulWidget {
  const ProductFormPage({super.key});
  @override
  State<ProductFormPage> createState() => _ProductFormPageState();
}

class _ProductFormPageState extends State<ProductFormPage> {
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final sku = TextEditingController();
  final category = TextEditingController();
  final color = TextEditingController();
  final size = TextEditingController();
  final stock = TextEditingController(text: '0');
  final cost = TextEditingController(text: '0');
  final sale = TextEditingController(text: '0');
  bool saving = false;

  @override
  void dispose() {
    for (final c in [name, sku, category, color, size, stock, cost, sale]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> save() async {
    if (!formKey.currentState!.validate()) return;
    setState(() => saving = true);
    try {
      await AppDatabase.instance.addProduct({
        'name': name.text.trim(),
        'sku': sku.text.trim(),
        'category': category.text.trim(),
        'color': color.text.trim(),
        'size': size.text.trim(),
        'stock': int.parse(stock.text),
        'cost_price': int.parse(cost.text),
        'sale_price': int.parse(sale.text),
        'created_at': DateTime.now().toIso8601String(),
      });
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('ذخیره انجام نشد: $e')));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Widget field(String label, TextEditingController c, {bool number = false, bool required = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: c,
        keyboardType: number ? TextInputType.number : TextInputType.text,
        decoration: InputDecoration(labelText: label),
        validator: (v) {
          if (required && (v == null || v.trim().isEmpty)) return 'این فیلد الزامی است';
          if (number && (int.tryParse(v ?? '') == null || int.parse(v!) < 0)) return 'عدد معتبر و غیرمنفی وارد کن';
          return null;
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ثبت محصول جدید')),
    body: Form(
      key: formKey,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          field('نام محصول *', name, required: true),
          field('کد محصول / SKU', sku),
          field('دسته‌بندی', category),
          field('رنگ', color),
          field('سایز', size),
          field('تعداد موجودی *', stock, number: true, required: true),
          field('قیمت خرید (تومان)', cost, number: true, required: true),
          field('قیمت فروش (تومان)', sale, number: true, required: true),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: saving ? null : save,
            icon: const Icon(Icons.save),
            label: Text(saving ? 'در حال ذخیره...' : 'ذخیره محصول'),
          ),
          const SizedBox(height: 8),
          const Text('در این مرحله، هر ثبت شامل یک ترکیب رنگ و سایز است. مدیریت چندرنگ/چندسایز مستقل و تصاویر محصول در مراحل بعدی اضافه می‌شود.',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
        ],
      ),
    ),
  );
}
