import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'data/app_database.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MeraApp());
}

class MeraApp extends StatelessWidget {
  const MeraApp({super.key});

  @override
  Widget build(BuildContext context) {
    const rose = Color(0xFFD99AAA);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MERA Manager',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: rose, surface: Colors.white),
        scaffoldBackgroundColor: const Color(0xFFF7F7F8),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Color(0xFF222222),
          centerTitle: true,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0.5,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFFF6F5F6),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide.none),
        ),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: MeraHome()),
    );
  }
}

class MeraHome extends StatefulWidget {
  const MeraHome({super.key});
  @override
  State<MeraHome> createState() => _MeraHomeState();
}

class _MeraHomeState extends State<MeraHome> {
  int tab = 0;
  int count = 0;
  int stock = 0;

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    final c = await AppDatabase.instance.productCount();
    final s = await AppDatabase.instance.totalStock();
    if (mounted) setState(() { count = c; stock = s; });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(count: count, stock: stock, onOpenProducts: () => setState(() => tab = 1)),
      ProductsPage(onChanged: refresh),
      const PlaceholderPage(title: 'انبار و گردش کالا', icon: Icons.inventory_2_outlined),
      const PlaceholderPage(title: 'سفارش‌ها و فروش', icon: Icons.shopping_bag_outlined),
      const PlaceholderPage(title: 'حساب‌ها و گزارش‌ها', icon: Icons.analytics_outlined),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('MERA Manager', style: TextStyle(fontWeight: FontWeight.w700, letterSpacing: .4)),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
        ],
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.checkroom_outlined), selectedIcon: Icon(Icons.checkroom), label: 'کالاها'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'انبار'),
          NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), label: 'سفارش'),
          NavigationDestination(icon: Icon(Icons.more_horiz), label: 'بیشتر'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key, required this.count, required this.stock, required this.onOpenProducts});
  final int count, stock;
  final VoidCallback onOpenProducts;

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(20)),
        child: Column(children: [
          Image.asset('assets/mera_logo_white.png', height: 110, fit: BoxFit.contain),
          const SizedBox(height: 8),
          const Text('مدیریت هوشمند بوتیک شما', style: TextStyle(color: Colors.white70, fontSize: 13)),
        ]),
      ),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(child: MetricCard(title: 'تعداد کالاها', value: '$count', icon: Icons.checkroom)),
        const SizedBox(width: 10),
        Expanded(child: MetricCard(title: 'موجودی کل', value: '$stock', icon: Icons.inventory_2_outlined)),
      ]),
      const SizedBox(height: 14),
      Card(child: ListTile(
        leading: const CircleAvatar(backgroundColor: Color(0xFFF5E5E9), child: Icon(Icons.add, color: Color(0xFF9C6073))),
        title: const Text('ثبت محصول جدید', style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: const Text('نام، قیمت، رنگ، سایز و موجودی'),
        trailing: const Icon(Icons.chevron_left),
        onTap: onOpenProducts,
      )),
      const SizedBox(height: 10),
      const Card(child: Padding(
        padding: EdgeInsets.all(16),
        child: Text('نسخه پایه MERA در حال توسعه است. اطلاعات این نسخه روی همین گوشی ذخیره می‌شود. برای استفاده واقعی، ابتدا نسخه پشتیبان و آزمون بازیابی باید اضافه و بررسی شود.', style: TextStyle(height: 1.7)),
      )),
    ],
  );
}

class MetricCard extends StatelessWidget {
  const MetricCard({super.key, required this.title, required this.value, required this.icon});
  final String title, value;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Card(child: Padding(
    padding: const EdgeInsets.all(16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: const Color(0xFFB8788C)),
      const SizedBox(height: 10),
      Text(value, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      Text(title, style: const TextStyle(color: Colors.black54)),
    ]),
  ));
}

class ProductsPage extends StatefulWidget {
  const ProductsPage({super.key, required this.onChanged});
  final VoidCallback onChanged;
  @override
  State<ProductsPage> createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  List<Map<String, Object?>> rows = [];
  bool busy = true;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    final result = await AppDatabase.instance.getProducts();
    if (mounted) setState(() { rows = result; busy = false; });
  }

  String money(Object? n) {
    final s = (n ?? 0).toString();
    return s.replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (_) => ',');
  }

  Future<void> add() async {
    final name = TextEditingController();
    final buy = TextEditingController(text: '0');
    final sell = TextEditingController(text: '0');
    final stock = TextEditingController(text: '0');
    final color = TextEditingController();
    final size = TextEditingController();
    String? photo;
    final picker = ImagePicker();

    final ok = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, setDialog) => AlertDialog(
        title: const Text('محصول جدید'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'نام محصول *')),
          const SizedBox(height: 8),
          TextField(controller: buy, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'قیمت خرید (تومان)')),
          const SizedBox(height: 8),
          TextField(controller: sell, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'قیمت فروش (تومان)')),
          const SizedBox(height: 8),
          TextField(controller: color, decoration: const InputDecoration(labelText: 'رنگ')),
          const SizedBox(height: 8),
          TextField(controller: size, decoration: const InputDecoration(labelText: 'سایز')),
          const SizedBox(height: 8),
          TextField(controller: stock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'موجودی اولیه')),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () async {
              final x = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
              if (x != null) setDialog(() => photo = x.path);
            },
            icon: const Icon(Icons.photo_library_outlined),
            label: Text(photo == null ? 'انتخاب عکس' : 'عکس انتخاب شد'),
          ),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لغو')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ذخیره')),
        ],
      ),
    ));

    if (ok == true && name.text.trim().isNotEmpty) {
      final b = int.tryParse(buy.text) ?? 0;
      final s = int.tryParse(sell.text) ?? 0;
      final q = int.tryParse(stock.text) ?? 0;
      if (b >= 0 && s >= 0 && q >= 0) {
        await AppDatabase.instance.addProduct(
          name: name.text.trim(), purchasePrice: b, salePrice: s,
          initialStock: q, color: color.text.trim(), size: size.text.trim(), imagePath: photo,
        );
        await load();
        widget.onChanged();
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.transparent,
    floatingActionButton: FloatingActionButton.extended(
      onPressed: add,
      backgroundColor: const Color(0xFFD99AAA),
      foregroundColor: Colors.white,
      icon: const Icon(Icons.add),
      label: const Text('ثبت کالا'),
    ),
    body: busy ? const Center(child: CircularProgressIndicator()) : rows.isEmpty
      ? const Center(child: Text('هنوز کالایی ثبت نشده است.'))
      : ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: rows.length,
          itemBuilder: (context, i) {
            final r = rows[i];
            final path = r['image_path'] as String?;
            return Card(
              child: ListTile(
                leading: path != null && File(path).existsSync()
                  ? ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File(path), width: 48, height: 48, fit: BoxFit.cover))
                  : const CircleAvatar(backgroundColor: Color(0xFFF5E5E9), child: Icon(Icons.checkroom, color: Color(0xFF9C6073))),
                title: Text(r['name'] as String),
                subtitle: Text('فروش: ${money(r['sale_price'])} تومان  •  موجودی: ${r['total_stock']}'),
                trailing: PopupMenuButton<String>(
                  onSelected: (v) async {
                    if (v == 'delete') {
                      await AppDatabase.instance.deleteProduct(r['id'] as int);
                      await load();
                      widget.onChanged();
                    }
                  },
                  itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('غیرفعال‌کردن کالا'))],
                ),
              ),
            );
          },
        ),
  );
}

class PlaceholderPage extends StatelessWidget {
  const PlaceholderPage({super.key, required this.title, required this.icon});
  final String title;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, size: 52, color: const Color(0xFFD99AAA)),
    const SizedBox(height: 12),
    Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('این بخش در گام بعدی پیاده‌سازی می‌شود.'),
  ]));
}
