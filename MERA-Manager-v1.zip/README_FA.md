# MERA Manager — Product module v0.2

This is the next development step for the MERA Android app.

## Included now
- Persian RTL interface
- Product registration with name, SKU, category, one color and one size
- Initial stock quantity
- Purchase and sale price in toman
- Local SQLite storage
- Product list, count and total stock
- Product deletion with confirmation

## Not included yet
Multi-variant stock matrix, persistent product image storage, inventory movement history,
orders, returns, accounting, Jalali calendar, Excel export, backup/restore, app lock,
and Instagram/Telegram API integration. These will be implemented and tested in later steps.

## Build
The repository workflow expects this ZIP at its root as `MERA-Manager-v1.zip`.
